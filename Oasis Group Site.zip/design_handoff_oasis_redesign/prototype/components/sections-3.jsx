/* eslint-disable */
function Contact() {
  const [form, setForm] = React.useState({
    name: '', email: '', org: '', interest: 'Digital Currency', message: '',
  });
  const [errors, setErrors] = React.useState({});
  const [status, setStatus] = React.useState('idle'); // idle | sending | success

  const upd = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: null }));
  };

  const validate = () => {
    const er = {};
    if (!form.name.trim()) er.name = 'Required';
    if (!form.email.trim()) er.email = 'Required';
    else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) er.email = 'Invalid email';
    if (!form.org.trim()) er.org = 'Required';
    if (!form.message.trim()) er.message = 'Required';
    return er;
  };

  const submit = (e) => {
    e.preventDefault();
    const er = validate();
    if (Object.keys(er).length) { setErrors(er); return; }
    setStatus('sending');
    setTimeout(() => setStatus('success'), 900);
  };

  return (
    <section id="contact" className="contact">
      <div className="shell">
        <Reveal>
          <div className="contact-card">
            <div className="contact-left">
              <div className="contact-eyebrow">Editorial</div>
              <h2 className="contact-title">
                Join us at<br/>the <em>frontier.</em>
              </h2>
              <p className="contact-blurb">
                The Oasis Group is a boutique advisory firm dedicated to
                pioneering collaborations in frontier technology and governance.
                We invite visionary governments, founders, and investors to
                explore strategic partnerships and shape the future of applied
                AI, digital assets, and policy.
              </p>
              <div className="contact-meta">
                <div className="contact-meta-row">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M4 4h16v16H4z" /><path d="M4 8l8 6 8-6" />
                  </svg>
                  <a href="mailto:hello@theoasisgroup.xyz">hello@theoasisgroup.xyz</a>
                </div>
                <div className="contact-meta-row">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <rect x="3" y="4" width="18" height="16" /><circle cx="8" cy="11" r="1" /><path d="M11 11h7M8 16h10" />
                  </svg>
                  <a href="https://linkedin.com/company/theoasisgroup" target="_blank" rel="noopener noreferrer">linkedin.com/company/theoasisgroup</a>
                </div>

              </div>
            </div>

            <div className="contact-right">
              {status === 'success' ? (
                <div className="contact-success">
                  <div className="contact-success-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M5 12l5 5L20 7" />
                    </svg>
                  </div>
                  <h3>Inquiry received.</h3>
                  <p>We'll be in touch within two business days.</p>
                </div>
              ) : (
                <form onSubmit={submit} noValidate>
                  <h3 className="contact-form-title">Partnership Inquiry</h3>
                  <div className="field-row">
                    <div className="field">
                      <label>Name</label>
                      <input type="text" value={form.name} onChange={upd('name')}
                             className={errors.name ? 'error' : ''} placeholder="Full name" />
                      {errors.name && <span className="field-error">{errors.name}</span>}
                    </div>
                    <div className="field">
                      <label>Email</label>
                      <input type="email" value={form.email} onChange={upd('email')}
                             className={errors.email ? 'error' : ''} placeholder="you@org.com" />
                      {errors.email && <span className="field-error">{errors.email}</span>}
                    </div>
                  </div>
                  <div className="field">
                    <label>Organization</label>
                    <input type="text" value={form.org} onChange={upd('org')}
                           className={errors.org ? 'error' : ''} placeholder="Central bank, ministry, fund, firm…" />
                    {errors.org && <span className="field-error">{errors.org}</span>}
                  </div>
                  <div className="field">
                    <label>Interest area</label>
                    <select value={form.interest} onChange={upd('interest')}>
                      <option>Digital Currency &amp; Financial Infrastructure</option>
                      <option>Applied AI &amp; Emerging Tech</option>
                      <option>Digital Coordination &amp; Governance</option>
                      <option>Venture Studio Partnership</option>
                      <option>Speaking / Press</option>
                    </select>
                  </div>
                  <div className="field">
                    <label>Tell us about your project</label>
                    <textarea rows={4} value={form.message} onChange={upd('message')}
                              className={errors.message ? 'error' : ''}
                              placeholder="The institutional context, the outcome you're after, any constraints we should know about." />
                    {errors.message && <span className="field-error">{errors.message}</span>}
                  </div>
                  <button type="submit" className="contact-submit" disabled={status === 'sending'}>
                    {status === 'sending' ? 'Sending…' : 'Send Inquiry →'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="shell">
        <div className="footer-grid">
          <div className="footer-brand">
            <BracketWordmark size="md" light />
            <p style={{ marginTop: 18 }}>
              Boutique advisory and venture studio building the digital
              frontier — from the Caribbean to the Global South.
            </p>
          </div>
          <div className="footer-col">
            <h4>Practice</h4>
            <ul>
              <li><a href="#practice">Digital Currency</a></li>
              <li><a href="#practice">Applied AI</a></li>
              <li><a href="#practice">Coordination &amp; Governance</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Ventures</h4>
            <ul>
              <li><a href="#work">Artisand</a></li>
              <li><a href="#work">DARE Advisor</a></li>
              <li><a href="#work">Oasis Onchain</a></li>
              <li><a href="#work">Frontier Founders</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Connect</h4>
            <ul>
              <li><a href="mailto:inquiry@theoasisgroup.xyz">Email</a></li>
              <li><a href="https://linkedin.com/company/theoasisgroup" target="_blank" rel="noopener noreferrer">LinkedIn</a></li>
              <li><a href="#">YouTube</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 The Oasis Group · Nassau, The Bahamas</span>
          <span>Bringing frontier tech home</span>
        </div>
      </div>
    </footer>
  );
}

window.Contact = Contact;
window.Footer = Footer;
