/* eslint-disable */
function TweaksController() {
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "accent": "gold",
    "showMarquee": true
  }/*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    document.body.setAttribute('data-accent', t.accent);
  }, [t.accent]);

  React.useEffect(() => {
    const m = document.querySelector('.hero-marquee');
    if (m) m.style.display = t.showMarquee ? 'block' : 'none';
  }, [t.showMarquee]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Accent" />
      <TweakRadio label="Color"
        value={t.accent}
        options={['gold', 'teal', 'coral']}
        onChange={(v) => setTweak('accent', v)} />
      <TweakSection label="Hero" />
      <TweakToggle label="Client marquee"
        value={t.showMarquee}
        onChange={(v) => setTweak('showMarquee', v)} />
    </TweaksPanel>
  );
}

function App() {
  return (
    <React.Fragment>
      <Navigation />
      <Hero />
      <About />
      <Practice />
      <Work />
      <Press />
      <Contact />
      <Footer />
      <TweaksController />
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
