/* eslint-disable */
function About() {
  return (
    <section id="about" className="section section-light">
      <div className="shell">
        <Reveal className="section-head">
          <div>
            <div className="section-tag">[ 01 ] Our Mission</div>
            <h2 className="section-title">
              Builders, not<br/>just <em>advisors.</em>
            </h2>
          </div>
          <p className="section-lead">
            The Oasis Group is a boutique consultancy and venture studio
            headquartered in The Bahamas — pioneering collaborations in frontier
            technology and governance across the Global South.
          </p>
        </Reveal>

        <div className="about-grid">
          <Reveal className="about-copy">
            <p>
              Most frontier technology is designed in Western markets and exported
              as an afterthought. The result? Frameworks that don't fit local
              realities, implementations that stall, and missed opportunities for
              the regions that could benefit most.
            </p>
            <p>
              <strong>The Oasis Group exists to change that equation.</strong> We
              combine deep technical expertise with direct experience inside central
              banks, regulatory bodies, and development institutions.
            </p>
            <p>
              Our founder, Stefen Deleveaux, has advised on digital currency
              strategy since 2017 — years before most nations had CBDC on their
              agenda. That practitioner knowledge, paired with a network of
              specialist partners, allows us to move from policy to production at
              the speed institutions actually need.
            </p>
          </Reveal>

          <Reveal delay={140} className="about-side">
            <div className="pull-tag">A note from the founder</div>
            <p className="pull">
              "Big consultancies deliver frameworks. We deliver implementation —
              at the speed and flexibility institutions actually need."
            </p>
            <hr/>
            <div className="signoff">
              <strong>Stefen Deleveaux</strong><br/>
              Founder · The Oasis Group<br/>
              Nassau, The Bahamas
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

const practiceAreas = [
  {
    num: '01',
    tag: 'Primary Focus',
    title: 'Digital Currency & Financial Infrastructure',
    desc: 'From policy design to technical implementation, we navigate the full lifecycle of digital currency and blockchain adoption for governments and financial institutions.',
    meta: 'Primary practice',
    capabilities: [
      'CBDC strategy & implementation advisory',
      'Blockchain integration (public + private sector)',
      'Regulatory framework development',
      'Financial inclusion infrastructure',
      'Cross-border payment systems',
    ],
    proof:
      'Advisor to the early Sand Dollar CBDC team in The Bahamas. Consulted with the Bank of Tanzania on digital assets and crypto policy. Multiple engagements with the Inter-American Development Bank.',
  },
  {
    num: '02',
    tag: 'Growing Practice',
    title: 'Applied AI & Emerging Tech',
    desc: "AI is reshaping how institutions operate. We help organizations move beyond the hype to practical, deployable solutions that respect local context.",
    meta: 'Growing practice',
    capabilities: [
      'AI implementation strategy',
      'Infrastructure & tooling assessment',
      'Deployment roadmaps for institutional contexts',
      'AI-assisted product development',
    ],
    proof:
      'Our venture Artisand — a full e-commerce platform built with AI-assisted development — demonstrates what is possible when emerging tools meet real-world institutional needs.',
  },
  {
    num: '03',
    tag: 'Supporting Practice',
    title: 'Digital Coordination & Governance',
    desc: 'New organizational models require new infrastructure. We design systems for transparent contribution tracking, distributed governance, and digital-native coordination.',
    meta: 'Supporting practice',
    capabilities: [
      'DAO architecture & governance design',
      'Contribution tracking systems',
      'Tooling for distributed teams',
      'Public-private coordination frameworks',
    ],
    proof:
      'Experience with Govrn, The DAOist, and pioneering contribution-based governance frameworks for institutions and ecosystems.',
  },
];

function Practice() {
  const [open, setOpen] = React.useState(0);
  const toggle = (i) => setOpen(open === i ? -1 : i);
  return (
    <section id="practice" className="section section-dark">
      <div className="shell">
        <Reveal className="section-head">
          <div>
            <div className="section-tag">[ 02 ] What we do</div>
            <h2 className="section-title">
              Expertise at<br/>the <em>edge.</em>
            </h2>
          </div>
          <p className="section-lead">
            We work at the intersection of policy, technology, and practical
            deployment — across three interconnected verticals.
          </p>
        </Reveal>

        <Reveal className="practice-list">
          {practiceAreas.map((p, i) => (
            <div key={p.num} className={`practice-row ${open === i ? 'open' : ''}`} onClick={() => toggle(i)}>
              <div className="practice-num">[ {p.num} ]</div>
              <div className="practice-title-wrap">
                <span className="practice-tag">{p.tag}</span>
                <div className="practice-title">{p.title}</div>
              </div>
              <div className="practice-desc">{p.desc}</div>
              <div className="practice-meta">
                <span>{p.meta}</span>
                <span className="practice-toggle" aria-hidden>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                </span>
              </div>
              <div className="practice-detail">
                <ul className="practice-cap-list">
                  {p.capabilities.map((c, j) => <li key={j}>{c}</li>)}
                </ul>
                <div className="practice-proof">
                  <span className="label">Proof points</span>
                  {p.proof}
                </div>
              </div>
            </div>
          ))}
        </Reveal>
      </div>
    </section>
  );
}

window.About = About;
window.Practice = Practice;
