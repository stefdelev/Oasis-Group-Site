/* eslint-disable */
// Shared bracket logo + ornaments
const { useState, useEffect, useRef } = React;

function BracketWordmark({ size = 'md', light = true }) {
  const fontSize = size === 'sm' ? 14 : size === 'lg' ? 24 : 16;
  const bracketH = fontSize * 1.5;
  const color = light ? '#fff' : 'var(--ink-900)';
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, color }}>
      <span style={{
        display: 'inline-block',
        width: 8,
        height: bracketH,
        borderTop: '1.5px solid currentColor',
        borderBottom: '1.5px solid currentColor',
        borderLeft: '1.5px solid currentColor',
      }} />
      <span style={{
        fontFamily: 'var(--sans)',
        fontWeight: 400,
        fontSize: fontSize,
        letterSpacing: '0.04em',
        whiteSpace: 'nowrap',
      }}>
        THE <strong style={{ fontWeight: 800, letterSpacing: '0.02em' }}>OASIS</strong> GROUP
      </span>
      <span style={{
        display: 'inline-block',
        width: 8,
        height: bracketH,
        borderTop: '1.5px solid currentColor',
        borderBottom: '1.5px solid currentColor',
        borderRight: '1.5px solid currentColor',
      }} />
    </div>
  );
}

// Reveal-on-scroll wrapper
function Reveal({ children, delay = 0, as: Tag = 'div', className = '', ...rest }) {
  const ref = useRef(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setShown(true), delay);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [delay]);
  return (
    <Tag ref={ref} className={`reveal ${shown ? 'in' : ''} ${className}`} {...rest}>
      {children}
    </Tag>
  );
}

// Globe / network SVG art for hero
function GlobeArt() {
  return (
    <svg viewBox="0 0 480 480" xmlns="http://www.w3.org/2000/svg" className="hero-art-svg" aria-hidden>
      <defs>
        <radialGradient id="globeGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(201,169,97,0.18)" />
          <stop offset="60%" stopColor="rgba(201,169,97,0.04)" />
          <stop offset="100%" stopColor="rgba(201,169,97,0)" />
        </radialGradient>
        <linearGradient id="meridian" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(201,169,97,0)" />
          <stop offset="50%" stopColor="rgba(201,169,97,0.55)" />
          <stop offset="100%" stopColor="rgba(201,169,97,0)" />
        </linearGradient>
      </defs>

      {/* Glow */}
      <circle cx="240" cy="240" r="220" fill="url(#globeGlow)" />

      {/* Outer ring */}
      <circle cx="240" cy="240" r="180" fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="1" />
      <circle cx="240" cy="240" r="140" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" strokeDasharray="2 6" />
      <circle cx="240" cy="240" r="100" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />

      {/* Latitude lines (ellipses) */}
      <ellipse cx="240" cy="240" rx="180" ry="60" fill="none" stroke="rgba(91,139,149,0.30)" strokeWidth="0.8" />
      <ellipse cx="240" cy="240" rx="180" ry="100" fill="none" stroke="rgba(91,139,149,0.22)" strokeWidth="0.8" />
      <ellipse cx="240" cy="240" rx="180" ry="140" fill="none" stroke="rgba(91,139,149,0.16)" strokeWidth="0.8" />

      {/* Longitude (meridians) */}
      <ellipse cx="240" cy="240" rx="60" ry="180" fill="none" stroke="url(#meridian)" strokeWidth="1" />
      <ellipse cx="240" cy="240" rx="100" ry="180" fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="0.8" />
      <ellipse cx="240" cy="240" rx="140" ry="180" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="0.8" />

      {/* Equator */}
      <line x1="60" y1="240" x2="420" y2="240" stroke="rgba(255,255,255,0.14)" strokeWidth="1" />
      <line x1="240" y1="60" x2="240" y2="420" stroke="rgba(255,255,255,0.10)" strokeWidth="1" />

      {/* Connection nodes */}
      {[
        [180, 180, 'Bahamas'],
        [310, 200, 'Cayman'],
        [200, 300, 'Trinidad'],
        [330, 320, 'Tanzania'],
        [150, 260, 'Mexico'],
        [285, 145, 'Cape Verde'],
      ].map(([cx, cy, name], i) => (
        <g key={i}>
          <circle cx={cx} cy={cy} r="14" fill="rgba(201,169,97,0.12)" className="globe-pulse" style={{ animationDelay: `${i * 0.5}s`, transformOrigin: `${cx}px ${cy}px` }} />
          <circle cx={cx} cy={cy} r="3.5" fill="#C9A961" />
        </g>
      ))}

      {/* Connection lines */}
      <g stroke="rgba(201,169,97,0.35)" strokeWidth="0.8" fill="none">
        <path d="M 180 180 Q 240 130 310 200" />
        <path d="M 180 180 Q 220 240 200 300" />
        <path d="M 310 200 Q 360 250 330 320" />
        <path d="M 200 300 Q 270 310 330 320" />
        <path d="M 150 260 Q 180 220 180 180" />
      </g>

      {/* Crosshair markers */}
      <g stroke="rgba(255,255,255,0.4)" strokeWidth="1">
        <line x1="60" y1="60" x2="80" y2="60" /><line x1="60" y1="60" x2="60" y2="80" />
        <line x1="420" y1="60" x2="400" y2="60" /><line x1="420" y1="60" x2="420" y2="80" />
        <line x1="60" y1="420" x2="80" y2="420" /><line x1="60" y1="420" x2="60" y2="400" />
        <line x1="420" y1="420" x2="400" y2="420" /><line x1="420" y1="420" x2="420" y2="400" />
      </g>
    </svg>
  );
}

// Topographic SVG used as work feature backdrop
function TopoArt({ seed = 1 }) {
  return (
    <svg viewBox="0 0 600 460" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <linearGradient id={`topo-bg-${seed}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1a3a52" />
          <stop offset="100%" stopColor="#0a1b33" />
        </linearGradient>
      </defs>
      <rect width="600" height="460" fill={`url(#topo-bg-${seed})`} />
      {/* Topo lines */}
      {Array.from({ length: 14 }).map((_, i) => {
        const y = 40 + i * 28 + Math.sin(seed + i) * 8;
        const wave = (x) => y + Math.sin(x / 60 + seed + i * 0.4) * (8 + i);
        let d = `M 0 ${wave(0).toFixed(1)}`;
        for (let x = 20; x <= 600; x += 20) d += ` L ${x} ${wave(x).toFixed(1)}`;
        return (
          <path
            key={i}
            d={d}
            fill="none"
            stroke={i % 4 === 0 ? 'rgba(201,169,97,0.35)' : 'rgba(91,139,149,0.30)'}
            strokeWidth={i % 4 === 0 ? 1 : 0.7}
          />
        );
      })}
      {/* Floating dots */}
      {[
        [120, 110], [220, 90], [320, 140], [430, 100], [180, 220], [340, 240], [470, 280], [240, 340], [380, 360]
      ].map(([cx, cy], i) => (
        <g key={i}>
          <circle cx={cx} cy={cy} r="2.5" fill="#C9A961" />
          <circle cx={cx} cy={cy} r="10" fill="rgba(201,169,97,0.10)" />
        </g>
      ))}
    </svg>
  );
}

window.BracketWordmark = BracketWordmark;
window.Reveal = Reveal;
window.GlobeArt = GlobeArt;
window.TopoArt = TopoArt;
