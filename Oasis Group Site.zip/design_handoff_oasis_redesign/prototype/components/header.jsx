/* eslint-disable */
const navItems = [
  { id: 'about', label: 'About' },
  { id: 'practice', label: 'Practice' },
  { id: 'work', label: 'Work' },
  { id: 'contact', label: 'Contact' },
];

function Navigation() {
  const [scrolled, setScrolled] = React.useState(false);
  const [active, setActive] = React.useState('');
  const [mobileOpen, setMobileOpen] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      // Section spy
      let current = '';
      for (const { id } of navItems) {
        const el = document.getElementById(id);
        if (el) {
          const r = el.getBoundingClientRect();
          if (r.top <= 120 && r.bottom > 200) current = id;
        }
      }
      setActive(current);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const goTo = (e, id) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 60;
      window.scrollTo({ top, behavior: 'smooth' });
    }
    setMobileOpen(false);
  };

  return (
    <nav className={`nav ${scrolled ? 'scrolled' : ''}`}>
      <div className="shell nav-row">
        <a href="#top" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
           className="nav-mark">
          <BracketWordmark size="sm" light />
        </a>
        <div className="nav-links">
          {navItems.map((it) => (
            <a key={it.id} href={`#${it.id}`}
               className={`nav-link ${active === it.id ? 'active' : ''}`}
               onClick={(e) => goTo(e, it.id)}>
              {it.label}
            </a>
          ))}
          <a href="#contact" className="nav-cta" onClick={(e) => goTo(e, 'contact')}>
            Partner with us
            <span className="arrow">→</span>
          </a>
        </div>
        <button className="nav-burger" onClick={() => setMobileOpen((v) => !v)} aria-label="Menu">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {mobileOpen ? <path d="M6 6L18 18M6 18L18 6" /> : <><path d="M4 7h16" /><path d="M4 12h16" /><path d="M4 17h16" /></>}
          </svg>
        </button>
      </div>
      <div className={`nav-mobile shell ${mobileOpen ? 'open' : ''}`}>
        {navItems.map((it) => (
          <a key={it.id} href={`#${it.id}`} onClick={(e) => goTo(e, it.id)}>{it.label}</a>
        ))}
        <a href="#contact" onClick={(e) => goTo(e, 'contact')}>Partner with us →</a>
      </div>
    </nav>
  );
}

function Hero() {
  const goContact = (e) => {
    e.preventDefault();
    const el = document.getElementById('contact');
    if (el) window.scrollTo({ top: el.offsetTop - 60, behavior: 'smooth' });
  };
  const goWork = (e) => {
    e.preventDefault();
    const el = document.getElementById('work');
    if (el) window.scrollTo({ top: el.offsetTop - 60, behavior: 'smooth' });
  };

  return (
    <section className="hero" id="top">
      <div className="shell hero-grid">
        <div>
          <div className="hero-eyebrow">Boutique advisory · Frontier technology</div>
          <h1 className="hero-title">
            Architects of the<br/>
            <em>Digital Frontier.</em>
          </h1>
          <p className="hero-sub">
            We help governments, central banks, and institutions implement digital currency,
            applied AI, and emerging-tech infrastructure — with the practitioner depth that
            theory alone can't deliver.
          </p>
          <div className="hero-actions">
            <a href="#contact" className="btn btn-primary" onClick={goContact}>
              Start a conversation
              <span className="arrow">→</span>
            </a>
            <a href="#work" className="btn btn-ghost" onClick={goWork}>
              See our work
            </a>
          </div>
          <div className="hero-stats">
            <div className="hero-stat">
              <div className="num">2017</div>
              <div className="lbl">Advising on<br/>digital currency</div>
            </div>
            <div className="hero-stat">
              <div className="num">12+</div>
              <div className="lbl">Sovereign &amp;<br/>institutional clients</div>
            </div>
            <div className="hero-stat">
              <div className="num">3</div>
              <div className="lbl">Live ventures<br/>in production</div>
            </div>
          </div>
        </div>

        <div className="hero-art float-slow">
          <div className="hero-art-frame"></div>
          <span className="hero-art-bracket tl"></span>
          <span className="hero-art-bracket tr"></span>
          <span className="hero-art-bracket bl"></span>
          <span className="hero-art-bracket br"></span>
          <GlobeArt />
          <div className="hero-art-meta">
            Reach<br/><strong>Caribbean → East Africa</strong>
          </div>
        </div>
      </div>

      <div className="hero-marquee" aria-hidden>
        <div className="marquee-track">
          {[
            'Central Bank of The Bahamas',
            'Sand Dollar CBDC',
            'Bank of Tanzania',
            'Inter-American Development Bank',
            'Forbes',
            'Oasis Onchain',
            'Artisand',
            'Frontier Founders',
            'Central Bank of The Bahamas',
            'Sand Dollar CBDC',
            'Bank of Tanzania',
            'Inter-American Development Bank',
            'Forbes',
            'Oasis Onchain',
            'Artisand',
            'Frontier Founders',
          ].map((t, i) => (
            <span key={i} className="marquee-item">{t}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

window.Navigation = Navigation;
window.Hero = Hero;
