/* eslint-disable */
function Work() {
  return (
    <section id="work" className="section section-light">
      <div className="shell">
        <Reveal className="section-head">
          <div>
            <div className="section-tag">[ 03 ] Our Work</div>
            <h2 className="section-title">
              Theory meets<br/><em>practice.</em>
            </h2>
          </div>
          <p className="section-lead">
            As a venture studio, we don't just consult — we build. Each engagement
            ships infrastructure, ventures, or policy frameworks that operate at
            real-world scale.
          </p>
        </Reveal>

        <Reveal>
          <article className="work-feature">
            <div className="work-feature-art">
              <img
                src="assets/artisand-screen2.png"
                alt="Artisand Marketplace — Discover Island Wonders"
                style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top center', display: 'block' }}
              />
            </div>
            <div className="work-feature-body">
              <span className="work-label">Featured Case Study · Artisand</span>
              <h3 className="work-feature-title">
                Scaling the artisanal economy through AI &amp; Web3.
              </h3>
              <p className="work-feature-desc">
                Artisand is a live e-commerce marketplace connecting Bahamian
                artisans directly with global customers. Built ground-up with
                AI-assisted development on a decentralized platform — production
                infrastructure that creates real economic opportunity.
              </p>

              <a href="https://www.artisand.art" target="_blank" rel="noopener noreferrer" className="btn btn-primary work-feature-link">
                Visit Artisand
                <span className="arrow">↗</span>
              </a>
            </div>
          </article>
        </Reveal>

        <div className="work-grid">
          {/* eslint-disable-next-line no-unused-vars */}
          {[
            {
              label: 'Venture · Bahamas',
              title: 'DARE Advisor',
              desc: 'AI-driven advisor that guides digital-asset businesses through the entire DARE Act registration process — from path selection to document generation.',
              link: 'Visit DARE Advisor',
              href: 'https://dare-advisor.vercel.app',
            },
            {
              label: 'Portfolio · Caribbean',
              title: 'Oasis Onchain',
              desc: 'Our flagship summit bringing together builders, policymakers, and investors focused on the Global South. Featured in Forbes.',
              link: 'Visit Oasis Onchain',
              href: 'https://www.oasisonchain.xyz',
              img: 'assets/oasis-onchain-event.jpeg',
            },
            {
              label: 'Portfolio · Media',
              title: 'Frontier Founders',
              desc: 'A podcast exploring frontier technology through the lens of founders actually doing the work — long-form conversations with builders shaping the future.',
              link: 'Watch on YouTube',
              href: 'https://www.youtube.com/@OasisFrontierFounders',
            },
          ].map((w, i) => (
            <Reveal key={i} delay={i * 80}>
              <article className="work-card" style={w.img ? {
                backgroundImage: `linear-gradient(to bottom, rgba(10,27,51,0.35) 0%, rgba(10,27,51,0.82) 60%), url(${w.img})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                color: '#fff',
                border: 'none',
              } : {}}>
                <span className="work-label" style={w.img ? { color: 'var(--accent)' } : {}}>{w.label}</span>
                <h4 className="work-card-title" style={w.img ? { color: '#fff' } : {}}>{w.title}</h4>
                <p className="work-card-desc" style={w.img ? { color: 'rgba(255,255,255,0.78)' } : {}}>{w.desc}</p>
                <a href={w.href} target="_blank" rel="noopener noreferrer" className="work-card-link">
                  {w.link} <span className="arrow">↗</span>
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Press() {
  return (
    <section className="press">
      <div className="shell">
        <div className="press-row">
          <span className="press-tag">In the press</span>
          <p className="press-quote">
            "Crypto Carib: Hotter Than Davos" — coverage of the Caribbean's
            emerging position in the global crypto landscape, featuring Oasis Onchain.
          </p>
          <a href="https://www.forbes.com/sites/digital-assets/2024/01/26/crypto-carib-hotter-than-davos/"
             target="_blank" rel="noopener noreferrer" className="press-source">
            Forbes <span className="arrow">↗</span>
          </a>
        </div>
      </div>
    </section>
  );
}

window.Work = Work;
window.Press = Press;
