# Handoff: The Oasis Group — Site Redesign

## Overview

This package contains a complete, high-fidelity redesign of **The Oasis Group** marketing site — a single-page React/TypeScript/Tailwind site for a boutique consultancy and venture studio operating in digital currency, applied AI, and emerging tech across the Global South.

The new direction replaces the original "dark mode + teal/orange accents" treatment with an **editorial / institutional-authority** aesthetic: deep navy + warm cream + gold accent, serif/sans pairing, bracket motif drawn from the logo, and richer interactivity throughout.

The target audience is government officials, central bank advisors, and institutional decision-makers — every design choice prioritizes credibility, restraint, and craft.

## About the Design Files

The files in `prototype/` are **design references** — a working HTML/React/Babel prototype showing the intended look, copy, and behavior. They are **not** production code to copy across verbatim.

Your task is to **recreate this design inside the existing target codebase** (`Oasis-Group-Site/` — React + TypeScript + Tailwind CSS v4 + Vite, with components already scaffolded under `src/components/`). Reuse the existing component file structure where possible. Translate the prototype's plain CSS into Tailwind utilities + `@theme` tokens; keep custom CSS only for things Tailwind can't express cleanly (the bracket SVG decorations, marquee animation, accordion transition).

## Fidelity

**High-fidelity.** Colors, typography, spacing, copy, animations, and interactions are all final. Recreate pixel-perfectly.

The only deliberately loose elements are:
- The hero globe SVG (custom-drawn — replicate the SVG directly from `prototype/components/shared.jsx → GlobeArt`)
- The Artisand and Oasis Onchain feature images (real screenshots provided in `prototype/assets/`)

## Tech Stack Mapping

| Prototype | Target codebase |
|---|---|
| Plain HTML + React 18 via Babel CDN | Existing React 18 + TypeScript + Vite setup in `Oasis-Group-Site/` |
| `styles.css` (plain CSS with custom properties) | Tailwind v4 `@theme` tokens in `src/index.css` + utility classes in components |
| `components/*.jsx` | `src/components/*.tsx` (replace existing files) |
| Google Fonts CDN link | Keep as `<link>` in `index.html` |
| `tweaks-panel.jsx` | **Do not port** — this is a design-tool-only feature |

## Design Tokens

### Colors

Add these to `src/index.css` `@theme` block (replacing the existing palette):

```css
@theme {
  /* Navy scale (primary surface) */
  --color-navy-900: #0A1B33;   /* primary brand, hero/footer/dark sections */
  --color-navy-800: #0F2542;
  --color-navy-700: #1A3252;
  --color-navy-600: #25406A;

  /* Cream scale (light surface) */
  --color-cream-50:  #F7F3E8;  /* light section background */
  --color-cream-100: #F1ECDD;  /* slight contrast (press strip, contact bg) */
  --color-cream-200: #E8E1CE;  /* card borders */
  --color-cream-300: #D4CCB4;  /* input borders */

  /* Ink scale (text on light) */
  --color-ink-900: #0A1B33;    /* primary text */
  --color-ink-700: #2B3A52;    /* body text */
  --color-ink-500: #5B6377;    /* lead / secondary */
  --color-ink-400: #7A8094;    /* muted */

  /* Accent: Gold (primary accent — replaces original cantaloupe) */
  --color-gold-500: #C9A961;   /* CTAs, eyebrows, accent lines */
  --color-gold-400: #D9BC78;   /* hover */
  --color-gold-300: #E4CC95;   /* italic text on dark */

  /* Secondary accent: muted teal */
  --color-teal-500: #5B8B95;
  --color-teal-400: #7BA8B0;

  /* Error / coral — used only for form validation */
  --color-coral-500: #D9764A;

  /* Border helper for dark sections */
  --color-navy-line: rgba(255, 255, 255, 0.08);
}
```

### Typography

Replace the single Inter font with this pairing:

```css
@theme {
  --font-serif: 'Fraunces', 'Times New Roman', Georgia, serif;
  --font-sans:  'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --font-mono:  'JetBrains Mono', ui-monospace, 'SFMono-Regular', Menlo, monospace;
}
```

Update Google Fonts `<link>` in `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,350;0,9..144,400;0,9..144,500;1,9..144,300;1,9..144,400&family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
```

**Type roles:**
- **Fraunces (serif)** — all section titles, hero headline, pull quote, work card titles, contact card title, footer brand. Weight `350` for headlines (light, editorial), italic for emphasis. Italics use the gold accent color on dark sections.
- **Inter (sans)** — body copy, buttons, nav, form fields. Weights 300/400/500/600/700.
- **JetBrains Mono** — eyebrows, section numbers (`[ 01 ]`), labels, metadata, footer column headers. Always uppercase, letter-spacing ~0.16–0.18em, size 11–12px.

**Hero headline:** `font-family: serif; font-weight: 350; font-size: clamp(48px, 7vw, 96px); line-height: 0.96; letter-spacing: -0.02em`. The italicized portion (`Digital Frontier.`) drops to `--color-gold-300`.

**Section titles:** `clamp(36px, 5vw, 64px); line-height: 1.02; letter-spacing: -0.02em; font-weight: 350`.

### Spacing

- Section padding: `120px 0` desktop, `80px 0` mobile
- Shell (max-width container): `max-width: 1280px; padding: 0 32px` (`0 20px` on mobile)
- Section header bottom margin: `64px`
- All hover transitions: `240–320ms cubic-bezier(.4,0,.2,1)`

### Other tokens

- Buttons and cards have **square corners** (no border-radius). The form inputs have `border-radius: 0`. This is intentional — part of the editorial/institutional feel. Only the success-state checkmark badge and globe nodes are circular.
- Shadows are used sparingly: only the contact card (`box-shadow: 0 28px 60px -28px rgba(10,27,51,0.18)`) and the primary CTA hover (`box-shadow: 0 14px 28px -12px rgba(201,169,97,0.5)`).

## The Bracket Motif

This is the design's signature. The Oasis Group logo is bracket-framed (`[ OASIS ]`), and the brackets recur as a unifying device:

1. **Wordmark in nav and footer** — text wrapped in CSS-drawn brackets (see `BracketWordmark` in `prototype/components/shared.jsx`)
2. **Hero art frame** — four `<span>` corner pieces in the gold accent over the globe
3. **Section eyebrows** — `[ 01 ] Our Mission`, `[ 02 ] What we do`, `[ 03 ] Our Work`
4. **Practice numbering** — `[ 01 ] / [ 02 ] / [ 03 ]` in mono
5. **About pull-quote card** — gold corner brackets at top-left and bottom-right
6. **Hero stats border-top** — single hairline divider in `--color-navy-line`

## Sections

### 1. Navigation (`Navigation.tsx`)

**Layout:** Fixed top, full-width, `padding: 18px 0` (collapses to `12px 0` after 40px scroll).

- Transparent → `rgba(10,27,51,0.92)` background with `backdrop-filter: blur(14px) saturate(140%)` on scroll
- Bottom border appears on scroll: `1px solid rgba(255,255,255,0.08)`

**Left:** `BracketWordmark` — "THE **OASIS** GROUP" in Inter, wrapped in CSS-drawn `[` and `]` shapes (8px wide, 1.5px borders, three sides only).

**Right:** Nav links + CTA button.
- Links: `text-transform: uppercase; letter-spacing: 0.06em; font-size: 13.5px; color: rgba(255,255,255,0.78)`
- Active link: white + gold underline that animates from right to left (right→0) on hover or active
- "Partner with us →" CTA: 1px gold border, transparent bg, hover fills gold + navy text

**Scrollspy:** Active nav link tracks current section based on `getBoundingClientRect`. See `prototype/components/header.jsx`.

**Mobile (≤880px):** Burger icon → reveals stacked menu below the nav row, navy bg, links separated by hairline dividers.

### 2. Hero (`Hero.tsx`)

**Layout:** `min-height: 100vh; padding: 140px 0 80px`, two-column grid `1.1fr 0.9fr` with 64px gap. Stacks on mobile.

**Background:**
- Base: `--color-navy-900`
- Two radial gradients layered: gold glow at 80% 20%, teal glow at 10% 90%, both at low opacity
- A subtle marquee strip is positioned absolutely at the bottom

**Left column:**
- Eyebrow: gold text + 28px gold line connector, mono uppercase, "Boutique advisory · Frontier technology"
- Headline (Fraunces 350): `Architects of the<br/><em>Digital Frontier.</em>` — italic gold portion uses `--color-gold-300`
- Sub: 18px Inter, `rgba(255,255,255,0.72)`, max-width 520px
- Two buttons: primary (gold bg, navy text, hover lifts + shadow) + ghost (1px white-25% border, fills slightly on hover). Both have a `→` arrow that translates 4px right on hover.
- Stats row: 3 columns, separated above by hairline. Numbers in serif gold (32px, weight 350), labels in mono uppercase muted white.

**Right column — globe art:**
- 480px square with `aspect-ratio: 1`
- Four 28×28 gold corner brackets (positioned absolutely at corners with `border` on two sides each)
- 1px white-10% inner frame
- Custom SVG (`GlobeArt` in `shared.jsx`): nested ellipses for latitudes/longitudes, gold connection lines between Caribbean → East Africa nodes, pulsing rings at each node (`animation: pulse-ring 3s ease-out infinite`)
- Top-right meta label: "Reach **Caribbean → East Africa**" in mono
- Whole art block has `animation: float-slow 6s ease-in-out infinite` (translates Y by 8px)

**Bottom marquee:** Absolute positioned at bottom of hero. `rgba(10,27,51,0.6)` bg, hairline top border, infinite-scroll mono text of client names separated by gold dots: `Central Bank of The Bahamas · Sand Dollar CBDC · Bank of Tanzania · Inter-American Development Bank · Forbes · Oasis Onchain · Artisand · Frontier Founders` (duplicated to make seamless loop). 40s linear infinite.

### 3. About (`About.tsx`)

**Layout:** Light section (`--color-cream-50`), section header grid (`0.8fr 1.2fr`), then 2-column body grid (1fr 1fr, 64px gap).

**Section header pattern (reused throughout):**
- Left: eyebrow `[ 01 ] Our Mission` + serif title `Builders, not<br/>just <em>advisors.</em>` (italic word in gold)
- Right (aligned to bottom): lead paragraph, 17px ink-500, max-width 540px

**Left content:** 3 paragraphs of body copy (17px Inter, line-height 1.7, ink-700). One `<strong>` highlighting the thesis sentence in ink-900.

**Right "founder card":** Navy-900 bg, 48×40 padding, gold corner brackets at top-left and bottom-right. Eyebrow "A note from the founder" in mono gold. Pull quote in serif italic 26px white. Hairline divider, then signoff in mono/sans: "**Stefen Deleveaux** / Founder · The Oasis Group / Nassau, The Bahamas".

**Copy:** Use the exact body in `prototype/components/sections-1.jsx → About`.

### 4. Practice (`Services.tsx` — rename concept to "Practice")

**Layout:** Dark section (`--color-navy-900`), section header same pattern, then a list of expandable rows.

This **replaces the original 3-card service grid** with an editorial list — each row is a click-to-expand row, mimicking a publication's table of contents.

**Each row:**
- 4-column grid: `80px 1.5fr 2fr 1fr`
- Hairline borders top and bottom in `rgba(255,255,255,0.10)`
- Left: `[ 01 ]` in mono gold
- Title column: small gray-tagged label ("Primary Focus") above a 32px serif title
- Description column: 15px white-66%, max-width 560px
- Right column: meta label + 36×36 toggle button (1px white-18% border, contains a `+` icon that rotates 45° to `×` when open)
- On hover: row slides 12px right, gold gradient sweeps in from the left (`linear-gradient(90deg, rgba(201,169,97,0.06), transparent 60%)`), toggle border + icon turn gold
- On click: `practice-detail` panel below expands (`max-height: 0 → 600px` over 520ms cubic-bezier(.4,0,.2,1))

**Expanded panel content:**
- Capabilities list with `→` gold bullets, each item 14.5px white-78%, separated by dashed hairlines
- Right side: italic "proof points" paragraph with mono "Proof points" label in gold above, separated by 1px white-10% left border with 24px padding-left

**Three rows:** Digital Currency & Financial Infrastructure, Applied AI & Emerging Tech, Digital Coordination & Governance. Full copy in `prototype/components/sections-1.jsx → practiceAreas`.

**Default state:** First row open. Mobile: collapses to 2 cols, hides desc + meta cols.

### 5. Work (`Work.tsx`)

**Layout:** Light section (`--color-cream-50`), section header, then a featured case study + 3-up portfolio grid.

**Featured Artisand case study:**
- 2-column grid (`1fr 1fr`), no gap, navy-900 background spanning both halves, white text
- Stacks on mobile
- Left: 460px-min image (`assets/artisand-screen2.png` — Artisand homepage screenshot, `object-fit: cover; object-position: top center`)
- Right: 56×48 padding, eyebrow "Featured Case Study · Artisand", serif headline "Scaling the artisanal economy through AI & Web3.", body copy, primary CTA "Visit Artisand ↗" linking to `https://www.artisand.art`

**Portfolio grid (3 cards):**
- 3-column grid, 24px gap, stacks on mobile
- Each card: 32×28 padding, min-height 320px, `--color-cream-100` bg, `--color-cream-200` border
- Hover: card flips to navy-900 bg, white text, lifts 4px (`transform: translateY(-4px)`)
- Card content: small `work-label` (gold mono uppercase), serif title, body copy, link with arrow at bottom

**The 3 portfolio items:**

| Card | Label | Title | URL | Special |
|---|---|---|---|---|
| 1 | "Venture · Bahamas" | DARE Advisor | `https://dare-advisor.vercel.app` | text card |
| 2 | "Portfolio · Caribbean" | Oasis Onchain | `https://www.oasisonchain.xyz` | **image bg** — `assets/oasis-onchain-event.jpeg` with linear-gradient overlay `rgba(10,27,51,0.35) → rgba(10,27,51,0.82)`; card stays white-text always |
| 3 | "Portfolio · Media" | Frontier Founders | `https://www.youtube.com/@OasisFrontierFounders` | text card |

All open in new tab (`target="_blank" rel="noopener noreferrer"`).

### 6. Press strip

Standalone band between Work and Contact. `--color-cream-100` bg, 56px vertical padding, hairline borders top and bottom.

3-column grid: mono eyebrow "In the press" + 28px gold-line / serif italic 22px quote / large serif "Forbes ↗" link. Quote: *"Crypto Carib: Hotter Than Davos" — coverage of the Caribbean's emerging position in the global crypto landscape, featuring Oasis Onchain.* Link to `https://www.forbes.com/sites/digital-assets/2024/01/26/crypto-carib-hotter-than-davos/`.

### 7. Contact (`Contact.tsx`)

**Layout:** Cream-100 background section (100px vertical padding). Centered card with 28px-blur navy shadow. Two columns inside the card.

**Left half (navy):**
- Decorative concentric circles in gold-18% / gold-8% positioned at bottom-right (-120px / -60px offsets)
- Eyebrow "Editorial"
- 44px serif title "Join us at<br/>the **frontier.**" (italic word gold-300)
- Blurb paragraph
- Meta rows with gold icons: email `mailto:hello@theoasisgroup.xyz`, LinkedIn `https://linkedin.com/company/theoasisgroup` (open in new tab)

**Right half (white, 56×48 padding):**
- Form title "Partnership Inquiry" in serif 28px
- Fields: Name + Email (2-col row), Organization, Interest (select with 5 options: Digital Currency / Applied AI / Coordination / Venture Studio / Speaking-Press), Message (4-row textarea)
- Inputs: 12×14 padding, 1px cream-300 border, square corners, gold focus ring + 3px shadow, coral border on validation error
- Submit button: navy-900 bg full-width, 16×24 padding, mono uppercase. On hover: gold bg + navy text.
- On success: replace form with centered checkmark badge (gold circle, navy check) + "Inquiry received." + "We'll be in touch within two business days."

**Validation:** Name, email (regex `/^[^@\s]+@[^@\s]+\.[^@\s]+$/`), organization, message all required. Error label below field in mono coral 10.5px uppercase.

In production this should hit a real backend (Netlify Forms, Formspree, or your own endpoint). The prototype just simulates a 900ms delay.

### 8. Footer (`Footer.tsx`)

**Layout:** Navy-900 bg, 80px top / 40px bottom padding. 4-column grid (`1.4fr 0.8fr 0.8fr 0.8fr`) with 48px gap. Stacks to 2-col on mobile.

**Cols:**
1. **Brand** — `BracketWordmark` (medium size) + tagline "Boutique advisory and venture studio building the digital frontier — from the Caribbean to the Global South."
2. **Practice** — Digital Currency / Applied AI / Coordination & Governance (anchors to `#practice`)
3. **Ventures** — Artisand / DARE Advisor / Oasis Onchain / Frontier Founders (anchors to `#work`)
4. **Connect** — Email (mailto) / LinkedIn / YouTube

Column headers in mono gold uppercase. Links in white-68%, hover gold.

**Bottom bar:** Hairline top border. Left: "© 2026 The Oasis Group · Nassau, The Bahamas". Right: "Bringing frontier tech home". Mono 12.5px white-48%.

## Interactions & Animations

| Element | Animation | Spec |
|---|---|---|
| Reveal-on-scroll | Fade + translate-y | All sections wrap content in a `<Reveal>` component using IntersectionObserver (threshold 0.12, rootMargin -8% bottom). On enter: `opacity: 0 → 1`, `translateY(24px) → 0`, `800ms ease`. Optional `delay` prop for stagger. |
| Nav scroll state | bg + padding transition | `320ms ease`. Triggers at `scrollY > 40`. |
| Nav scrollspy | Active link underline | Pseudo-element animates `right: 100% → 0` over 320ms. |
| Hero art | Float | `translateY(0 → -8px → 0)` over 6s ease-in-out infinite. |
| Globe nodes | Pulse | `scale(1) → scale(1.6); opacity 0.4 → 0` over 3s ease-out infinite. Stagger each node by 0.5s. |
| Marquee | Linear scroll | `translateX(0 → -50%)` over 40s linear infinite. Track is content × 2. |
| Practice row hover | Indent + gradient sweep | Padding-left `0 → 12px` (320ms), gradient pseudo-element width `0 → 100%` (480ms). |
| Practice row open | Detail expand | `max-height: 0 → 600px` over 520ms cubic-bezier(.4,0,.2,1). Toggle icon rotates 45° (320ms). |
| Work card hover | Color flip + lift | Bg cream-100 → navy-900, all text colors swap, `translateY(-4px)`. 320ms cubic-bezier(.4,0,.2,1). |
| CTA button hover | Lift + shadow | `translateY(-1px)` + gold glow shadow. Arrow translates 4px right. |
| Selection | Highlight | `::selection { background: gold-500; color: navy-900 }`. |

## Asset Inventory

Copy from `prototype/assets/` into the target codebase's `public/images/`:

- `oasis-logo.png` — kept from original (already exists)
- `artisand-screen2.png` — Artisand site screenshot, used as featured case study image
- `oasis-onchain-event.jpeg` — Event photo, used as Oasis Onchain card background
- `artisand-screen.jpg` — alternate Artisand crop (kept for reference, not used in final)

The hero globe and topographic backdrops are SVG-only, drawn inline in `shared.jsx` (`GlobeArt`, `TopoArt`). Port `GlobeArt` directly. `TopoArt` is no longer used in the final design (replaced by the Artisand screenshot) and can be omitted.

## Implementation Notes

1. **Tailwind v4 syntax** — the existing codebase uses `@theme` directly in CSS (not `tailwind.config.js`). Add the new tokens to the existing `@theme` block in `src/index.css`.

2. **Replace, don't merge** — The old palette names (`oasisDeep`, `oasisAction`, `oasisSunset`, etc.) should be **removed**. The new design uses semantic navy/cream/gold names that read clearly in JSX.

3. **Component file mapping:**
   - `Hero.tsx` — full rewrite
   - `Navigation.tsx` — full rewrite (add scrollspy + bracket wordmark)
   - `About.tsx` — full rewrite (new founder card)
   - `Services.tsx` — full rewrite as accordion list (consider renaming to `Practice.tsx`)
   - `ServiceCard.tsx` — **delete** (no longer used)
   - `Work.tsx` — full rewrite (featured + grid)
   - `WorkCard.tsx` — refactor to support `img` prop for image-bg variant
   - `Press.tsx` — full rewrite as horizontal strip
   - `Contact.tsx` — full rewrite (split card layout, validation, success state)
   - `Footer.tsx` — full rewrite (4-col)
   - `CredibilityBar.tsx` — **delete** (replaced by hero marquee)

4. **New shared components to add:**
   - `BracketWordmark` (used in nav + footer)
   - `Reveal` (intersection-observer wrapper, used everywhere)
   - `GlobeArt` (hero SVG)

5. **Smooth scroll** — Keep `html { scroll-behavior: smooth }` in `index.css`. Nav `goTo` handler should subtract 60px from offset to account for fixed nav height.

6. **Form backend** — The original codebase used Netlify Forms (`data-netlify="true"`, hidden form-name input). Keep that wiring; the prototype's `setTimeout` is just a stand-in. Show the success state on actual form submission success.

7. **Ignore the Tweaks panel** — `tweaks-panel.jsx` and the `TweaksController` in `app.jsx` are design-time scaffolding. Do not port. The site ships with **gold accent only** — the teal/coral variants are exploration leftovers.

8. **Accessibility:**
   - All form inputs need proper `<label>` elements (the prototype uses visible labels above each field, which is correct — keep them)
   - Nav burger toggles `aria-expanded`
   - Animations should respect `prefers-reduced-motion` — wrap `Reveal` and the float/pulse keyframes in a `@media (prefers-reduced-motion: no-preference)` guard
   - All interactive elements keyboard accessible — the `<a>`-as-button anchor pattern is fine since they're true links/anchors
   - Color contrast: gold (#C9A961) on navy passes AA for large text only; use it for headings/eyebrows/icons, never for sustained body copy on dark backgrounds

## Screenshots

Reference renders of the prototype at desktop width are in `screenshots/`:

| File | Section |
|---|---|
| `01-hero.png` | Hero — globe art, headline, stats, marquee |
| `02-about.png` | About / mission + founder pull-quote card |
| `03-practice.png` | Practice areas accordion (first row open) |
| `04-work-featured.png` | Work section header + featured Artisand case study |
| `05-work-grid.png` | Portfolio grid (DARE, Oasis Onchain w/ image bg, Frontier Founders) |
| `06-contact.png` | Editorial contact card |
| `07-footer.png` | Footer + bottom bar |

## Files in `prototype/`

| File | Purpose |
|---|---|
| `index.html` | Entry, Google Fonts link, script imports |
| `styles.css` | All design styles (translate to Tailwind) |
| `components/shared.jsx` | `BracketWordmark`, `Reveal`, `GlobeArt`, `TopoArt` |
| `components/header.jsx` | `Navigation`, `Hero` |
| `components/sections-1.jsx` | `About`, `Practice` |
| `components/sections-2.jsx` | `Work`, `Press` |
| `components/sections-3.jsx` | `Contact`, `Footer` |
| `components/app.jsx` | App composition (ignore `TweaksController`) |
| `tweaks-panel.jsx` | **Ignore — design-tool scaffolding** |
| `assets/` | Real imagery to copy into `public/images/` |

To preview the prototype locally: open `prototype/index.html` directly in a browser, or serve it with `npx http-server prototype/`.

---

**Questions for the design team while implementing:** the Artisand featured case study currently CTAs to the live site. Eventually you may want a dedicated `/case-studies/artisand` route — leave the link target flexible.
